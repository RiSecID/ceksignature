package com.risecid.ceksign;

import android.app.*;
import android.os.*;
import com.risecid.util.SignatureUtils;
import android.widget.*;
import android.util.*;
import android.content.pm.PackageInfo;
import java.security.MessageDigest;
import android.content.pm.PackageManager;
import java.security.NoSuchAlgorithmException;
import android.content.pm.Signature;
import android.content.*;
import android.view.*;


public class MainActivity extends Activity 
{
	
	TextView anu1,anu2;
	Button copi;
	private ClipboardManager myClipboard;
	private ClipData myClip;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		copi = (Button) findViewById(R.id.copi);
		myClipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
		anu1 = (TextView) findViewById(R.id.anu1);
		anu2 = (TextView) findViewById(R.id.anu2);
		
		copi.setOnClickListener(new View.OnClickListener() {


				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub


					String text = anu2.getText().toString();
					myClip = ClipData.newPlainText("text", text);
					myClipboard.setPrimaryClip(myClip);
					Toast.makeText(getApplicationContext(), "Signature Copied", 
								   Toast.LENGTH_SHORT).show(); 
				}
			});
		
		generateHashkey();
		Cekking();
    }
	
	
	//Cekking your Signature
	public void Cekking()
	{
        try
		{
            if (SignatureUtils.checkSignature(this))
			{
				Toast.makeText(getApplicationContext(), "Signature Valid", 
							   Toast.LENGTH_SHORT).show(); 
            }
			else
			{
                
				Toast.makeText(getApplicationContext(), "Invalid Signature", 
							   Toast.LENGTH_SHORT).show(); 
							   //finishAffinity();
							   
							   //To close your app if signature invalid
				
            }
        }
		catch (Exception e)
		{
            Log.d("slup", e.toString());
        }
    }
	
	//method only for checking your signature after sign with your keystrore
	public void generateHashkey(){
        try {
            PackageInfo info = getPackageManager().getPackageInfo("com.risecid.ceksign" ,PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());

                anu1.setText(info.packageName);
                anu2.setText(Base64.encodeToString(md.digest(),
																					   Base64.NO_WRAP));
																					   
            }
        } catch (PackageManager.NameNotFoundException e) {
        } catch (NoSuchAlgorithmException e) {
        }
    }
}
