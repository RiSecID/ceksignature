package com.risecid.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;
import android.util.Log;

import java.security.MessageDigest;
import android.widget.*;

public class SignatureUtils {
	
	TextView tv;

    private static final String TAG = SignatureUtils.class.getSimpleName();
    private static final String SIGNATURE = "jVD10IoFJkpAH77C9Xt7qpPkDJE="; // Paste Your Signature Here

    public static boolean checkSignature(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
				.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : packageInfo.signatures) {
                MessageDigest sha = MessageDigest.getInstance("SHA");
                sha.update(signature.toByteArray());
                final String currentSignature = Base64.encodeToString(sha.digest(), Base64.NO_WRAP);
                if (SIGNATURE.equals(currentSignature)) {
                    return true;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to check signature", e);
        }

        return false;
    }
}
